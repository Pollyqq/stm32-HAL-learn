/**
  ******************************************************************************
  * File Name          : LTDC.c
  * Description        : This file provides code for the configuration
  *                      of the LTDC instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "ltdc.h"

/* USER CODE BEGIN 0 */
#include "dma2d.h"
//LCD֡�������׵�ַ,���ﶨ����SDRAM����.
#define LCD_FRAME_BUF_ADDR			0XC0000000
// ÿ������ռ�õ��ֽ���
#define PIXELS_BYTE 2
//����������ֱ���ʱ,LCD�����֡���������С
uint16_t g_ltdc_framebuf[PIXELS_W][PIXELS_H] __attribute__((at(LCD_FRAME_BUF_ADDR)));
/* USER CODE END 0 */

LTDC_HandleTypeDef hltdc;

/* LTDC init function */
void MX_LTDC_Init(void)
{
    LTDC_LayerCfgTypeDef pLayerCfg = {0};
    LTDC_LayerCfgTypeDef pLayerCfg1 = {0};

    hltdc.Instance = LTDC;
    hltdc.Init.HSPolarity = LTDC_HSPOLARITY_AL;
    hltdc.Init.VSPolarity = LTDC_VSPOLARITY_AL;
    hltdc.Init.DEPolarity = LTDC_DEPOLARITY_AL;
    hltdc.Init.PCPolarity = LTDC_PCPOLARITY_IPC;
    hltdc.Init.HorizontalSync = 20-1;
    hltdc.Init.VerticalSync = 2;
    hltdc.Init.AccumulatedHBP = 20-1+140;
    hltdc.Init.AccumulatedVBP = 22;
    hltdc.Init.AccumulatedActiveW = 20-1+140+PIXELS_W;
    hltdc.Init.AccumulatedActiveH = 622;
    hltdc.Init.TotalWidth = 20-1+140+PIXELS_W+160;
    hltdc.Init.TotalHeigh = 634;
    hltdc.Init.Backcolor.Blue = 0;
    hltdc.Init.Backcolor.Green = 0;
    hltdc.Init.Backcolor.Red = 0;
    if (HAL_LTDC_Init(&hltdc) != HAL_OK)
    {
        Error_Handler();
    }
    pLayerCfg.WindowX0 = 0;
    pLayerCfg.WindowX1 = PIXELS_W;
    pLayerCfg.WindowY0 = 0;
    pLayerCfg.WindowY1 = PIXELS_H;
    pLayerCfg.PixelFormat = LTDC_PIXEL_FORMAT_RGB565;
    pLayerCfg.Alpha = 255;
    pLayerCfg.Alpha0 = 0;
    pLayerCfg.BlendingFactor1 = LTDC_BLENDING_FACTOR1_CA;
    pLayerCfg.BlendingFactor2 = LTDC_BLENDING_FACTOR2_CA;
    pLayerCfg.FBStartAdress = LTDC_BUFF_ADDR;
    pLayerCfg.ImageWidth = 0;
    pLayerCfg.ImageHeight = 0;
    pLayerCfg.Backcolor.Blue = 0;
    pLayerCfg.Backcolor.Green = 0;
    pLayerCfg.Backcolor.Red = 0;
    if (HAL_LTDC_ConfigLayer(&hltdc, &pLayerCfg, 0) != HAL_OK)
    {
        Error_Handler();
    }
    pLayerCfg1.WindowX0 = 0;
    pLayerCfg1.WindowX1 = 1024;
    pLayerCfg1.WindowY0 = 0;
    pLayerCfg1.WindowY1 = 600;
    pLayerCfg1.Alpha = 0;
    pLayerCfg1.Alpha0 = 255;
    pLayerCfg1.BlendingFactor1 = LTDC_BLENDING_FACTOR1_CA;
    pLayerCfg1.BlendingFactor2 = LTDC_BLENDING_FACTOR2_CA;
    pLayerCfg1.FBStartAdress = 0;
    pLayerCfg1.ImageWidth = 0;
    pLayerCfg1.ImageHeight = 0;
    pLayerCfg1.Backcolor.Blue = 0;
    pLayerCfg1.Backcolor.Green = 0;
    pLayerCfg1.Backcolor.Red = 0;
    if (HAL_LTDC_ConfigLayer(&hltdc, &pLayerCfg1, 1) != HAL_OK)
    {
        Error_Handler();
    }

}

void HAL_LTDC_MspInit(LTDC_HandleTypeDef* ltdcHandle)
{

    GPIO_InitTypeDef GPIO_InitStruct = {0};
    if(ltdcHandle->Instance==LTDC)
    {
        /* USER CODE BEGIN LTDC_MspInit 0 */

        /* USER CODE END LTDC_MspInit 0 */
        /* LTDC clock enable */
        __HAL_RCC_LTDC_CLK_ENABLE();

        __HAL_RCC_GPIOI_CLK_ENABLE();
        __HAL_RCC_GPIOF_CLK_ENABLE();
        __HAL_RCC_GPIOH_CLK_ENABLE();
        __HAL_RCC_GPIOG_CLK_ENABLE();
        /**LTDC GPIO Configuration
        PI9     ------> LTDC_VSYNC
        PI10     ------> LTDC_HSYNC
        PF10     ------> LTDC_DE
        PH9     ------> LTDC_R3
        PH10     ------> LTDC_R4
        PH11     ------> LTDC_R5
        PH12     ------> LTDC_R6
        PG6     ------> LTDC_R7
        PG7     ------> LTDC_CLK
        PH13     ------> LTDC_G2
        PH14     ------> LTDC_G3
        PH15     ------> LTDC_G4
        PI0     ------> LTDC_G5
        PI1     ------> LTDC_G6
        PI2     ------> LTDC_G7
        PG11     ------> LTDC_B3
        PI4     ------> LTDC_B4
        PI5     ------> LTDC_B5
        PI6     ------> LTDC_B6
        PI7     ------> LTDC_B7
        */
        GPIO_InitStruct.Pin = GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_0|GPIO_PIN_1
                              |GPIO_PIN_2|GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6
                              |GPIO_PIN_7;
        GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
        GPIO_InitStruct.Alternate = GPIO_AF14_LTDC;
        HAL_GPIO_Init(GPIOI, &GPIO_InitStruct);

        GPIO_InitStruct.Pin = GPIO_PIN_10;
        GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
        GPIO_InitStruct.Alternate = GPIO_AF14_LTDC;
        HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

        GPIO_InitStruct.Pin = GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12
                              |GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
        GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
        GPIO_InitStruct.Alternate = GPIO_AF14_LTDC;
        HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);

        GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_11;
        GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
        GPIO_InitStruct.Alternate = GPIO_AF14_LTDC;
        HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

        /* USER CODE BEGIN LTDC_MspInit 1 */



        /* USER CODE END LTDC_MspInit 1 */
    }
}

void HAL_LTDC_MspDeInit(LTDC_HandleTypeDef* ltdcHandle)
{

    if(ltdcHandle->Instance==LTDC)
    {
        /* USER CODE BEGIN LTDC_MspDeInit 0 */

        /* USER CODE END LTDC_MspDeInit 0 */
        /* Peripheral clock disable */
        __HAL_RCC_LTDC_CLK_DISABLE();

        /**LTDC GPIO Configuration
        PI9     ------> LTDC_VSYNC
        PI10     ------> LTDC_HSYNC
        PF10     ------> LTDC_DE
        PH9     ------> LTDC_R3
        PH10     ------> LTDC_R4
        PH11     ------> LTDC_R5
        PH12     ------> LTDC_R6
        PG6     ------> LTDC_R7
        PG7     ------> LTDC_CLK
        PH13     ------> LTDC_G2
        PH14     ------> LTDC_G3
        PH15     ------> LTDC_G4
        PI0     ------> LTDC_G5
        PI1     ------> LTDC_G6
        PI2     ------> LTDC_G7
        PG11     ------> LTDC_B3
        PI4     ------> LTDC_B4
        PI5     ------> LTDC_B5
        PI6     ------> LTDC_B6
        PI7     ------> LTDC_B7
        */
        HAL_GPIO_DeInit(GPIOI, GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_0|GPIO_PIN_1
                        |GPIO_PIN_2|GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6
                        |GPIO_PIN_7);

        HAL_GPIO_DeInit(GPIOF, GPIO_PIN_10);

        HAL_GPIO_DeInit(GPIOH, GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12
                        |GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15);

        HAL_GPIO_DeInit(GPIOG, GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_11);

        /* USER CODE BEGIN LTDC_MspDeInit 1 */

        /* USER CODE END LTDC_MspDeInit 1 */
    }
}

/* USER CODE BEGIN 1 */

// ��Դ��
void LTDC_ON(void)
{
    HAL_GPIO_WritePin(LCD_BK_GPIO_Port,LCD_BK_Pin,1);
}
// ��Դ�ر�
void LTDC_OFF(void)
{
    HAL_GPIO_WritePin(LCD_BK_GPIO_Port,LCD_BK_Pin,0);
}
// ��ʼ��
void LTDC_Init(void)
{

    HAL_LTDC_SetWindowPosition(&hltdc,0,0,0);  //���ô��ڵ�λ��
    HAL_LTDC_SetWindowSize(&hltdc,PIXELS_W,PIXELS_H,0);//���ô��ڴ�С

    LTDC_ON();
    LTDC_Clear(BLACK);         //����
    return;
}

// ����
void LTDC_Clear(uint32_t color)
{
    LTDC_Fill(0,0,PIXELS_H-1,PIXELS_W-1,color);
}

//���㺯��
void LTDC_Draw_Point(uint16_t x,uint16_t y,uint32_t color)
{
    //����ϵת��
    if(PIXELS_DIR)	//����
    {
        *(uint16_t*)((uint32_t)LCD_FRAME_BUF_ADDR+PIXELS_BYTE*(PIXELS_W*y+x))=color;
    } else			//����
    {
        *(uint16_t*)((uint32_t)LCD_FRAME_BUF_ADDR+PIXELS_BYTE*(PIXELS_W*(PIXELS_H-x-1)+y))=color;
    }
}
//���㺯��
uint32_t LTDC_Read_Point(uint16_t x,uint16_t y)
{
    //����ϵת��
    if(PIXELS_DIR)	//����
    {
        return *(uint16_t*)((uint32_t)LCD_FRAME_BUF_ADDR+PIXELS_BYTE*(PIXELS_W*y+x));
    } else			//����
    {
        return *(uint16_t*)((uint32_t)LCD_FRAME_BUF_ADDR+PIXELS_BYTE*(PIXELS_W*(PIXELS_H-x-1)+y));
    }
}

//LTDC������,DMA2D���
//(sx,sy),(ex,ey):�����ζԽ�����,�����СΪ:(ex-sx+1)*(ey-sy+1)
//color:Ҫ������ɫ
//��ʱ����ҪƵ���ĵ�����亯��������Ϊ���ٶȣ���亯�����üĴ����汾��
//���������ж�Ӧ�Ŀ⺯���汾�Ĵ��롣
void LTDC_Fill(uint16_t sx,uint16_t sy,uint16_t ex,uint16_t ey,uint32_t color)
{
    uint32_t psx,psy,pex,pey;	//��LCD���Ϊ��׼������ϵ,����������仯���仯
    uint32_t timeout=0;
    uint16_t offline;
    uint32_t addr;

    //����ϵת��
    if(PIXELS_DIR)	//����
    {
        psx=sx;
        psy=sy;
        pex=ex;
        pey=ey;
    } else			//����
    {
        psx=sy;
        psy=PIXELS_H-ex-1;
        pex=ey;
        pey=PIXELS_H-sx-1;
    }
    offline=PIXELS_W-(pex-psx+1);
    addr=(LCD_FRAME_BUF_ADDR+PIXELS_BYTE*(PIXELS_W*psy+psx));

    __HAL_RCC_DMA2D_CLK_ENABLE();	//ʹ��DM2Dʱ��
    DMA2D->CR&=~(DMA2D_CR_START);	//��ֹͣDMA2D
    DMA2D->CR=DMA2D_R2M;			//�Ĵ������洢��ģʽ
    DMA2D->OPFCCR=LTDC_PIXEL_FORMAT_RGB565;	//������ɫ��ʽ
    DMA2D->OOR=offline;				//������ƫ��

    DMA2D->OMAR=addr;				//����洢����ַ
    DMA2D->NLR=(pey-psy+1)|((pex-psx+1)<<16);	//�趨�����Ĵ���
    DMA2D->OCOLR=color;						//�趨�����ɫ�Ĵ���
    DMA2D->CR|=DMA2D_CR_START;				//����DMA2D
    while((DMA2D->ISR&(DMA2D_FLAG_TC))==0)	//�ȴ��������
    {
        timeout++;
        if(timeout>0X1FFFFF)break;	//��ʱ�˳�
    }
    DMA2D->IFCR|=DMA2D_FLAG_TC;		//���������ɱ�־
}

//���β�ɫ��亯��
void LTDC_Color_Fill(uint16_t sx,uint16_t sy,uint16_t ex,uint16_t ey,uint16_t *color)
{
uint32_t psx,psy,pex,pey;	//��LCD���Ϊ��׼������ϵ,����������仯���仯
    uint32_t timeout=0;
    uint16_t offline;
    uint32_t addr;

    //����ϵת��
    if(PIXELS_DIR)	//����
    {
        psx=sx;
        psy=sy;
        pex=ex;
        pey=ey;
    } else			//����
    {
        psx=sy;
        psy=PIXELS_H-ex-1;
        pex=ey;
        pey=PIXELS_H-sx-1;
    }
    offline=PIXELS_W-(pex-psx+1);
    addr=(LCD_FRAME_BUF_ADDR+PIXELS_BYTE*(PIXELS_W*psy+psx));

    __HAL_RCC_DMA2D_CLK_ENABLE();	//ʹ��DM2Dʱ��
    DMA2D->CR&=~(DMA2D_CR_START);	//��ֹͣDMA2D
    DMA2D->CR=DMA2D_R2M;			//�Ĵ������洢��ģʽ
    DMA2D->OPFCCR=LTDC_PIXEL_FORMAT_RGB565;	//������ɫ��ʽ
    DMA2D->OOR=offline;				//������ƫ��

		DMA2D->FGMAR=(uint32_t)color;		//Դ��ַ
		DMA2D->OMAR=addr;				//����洢����ַ
		DMA2D->NLR=(pey-psy+1)|((pex-psx+1)<<16);	//�趨�����Ĵ��� 
		DMA2D->CR|=DMA2D_CR_START;					//����DMA2D
    while((DMA2D->ISR&(DMA2D_FLAG_TC))==0)	//�ȴ��������
    {
        timeout++;
        if(timeout>0X1FFFFF)break;	//��ʱ�˳�
    }
    DMA2D->IFCR|=DMA2D_FLAG_TC;		//���������ɱ�־
}



/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
