#ifndef _ft5206_H
#define _ft5206_H

#include "main.h"

void ft5206_init(void);
#endif
